﻿int main() {

    void title(int var) {
        setlocale(LC_ALL, "");
        std::cout << "Выполнила: Литвинова Таисия\n";
        if (var != -1) {
            std::cout << "Вариант: " << var << '\n';
        }
        std::cout << "Задание 7\n";
    }
    //что нибудь напиши в return
}

